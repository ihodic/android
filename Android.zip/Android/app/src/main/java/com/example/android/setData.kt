package com.example.android


object setData {

    const val name:String="name"
    const val score:String="score"

    fun getQuestion():ArrayList<QuestionData>{
        var que:ArrayList<QuestionData> = arrayListOf()

        var question1 = QuestionData(
            1,
            "Koji je glavni grad Češke ?",

            "Ljubljana",
            "Zagreb",
            "Budimpešta",
            "Prag",
            4
        )
        var question2 = QuestionData(
            2,
            "Koliko je 10 - 10 x 10 + 10 ?",

            "-80",
            "0",
            "80",
            "Niti jedno",
            1
        )
        var question3 = QuestionData(
            3,
            "Koje je godine Hrvatska ušla u EU ?",

            "2010",
            "2013",
            "2012",
            "2014",
            2
        )
        var question4 = QuestionData(
            4,
            "Koji je najvišlji planinski vrh u Japanu ?",

            "Komori",
            "Shomi",
            "Fuji",
            "Jari",
            3
        )

        var question5 = QuestionData(
            5,
            "Koliko prstenova ima olimpijska zastava ?",

            "1",
            "6",
            "4",
            "5",
            4
        )

        que.add(question1)
        que.add(question2)
        que.add(question3)
        que.add(question4)
        que.add(question5)
        return que
    }
}